const express = require('express');
const app = express();
const PORT = 3001;

const mongoose = require('mongoose')
const cors = require('cors')
const crypto = require('crypto')

app.use(express.json())
app.use(cors());
app.use(express.urlencoded({ extended: true }));


const UserModal = require('./model/User_Modal')
const Question = require('./model/question_Modal')
const Point = require('./model/Point')

mongoose.connect('mongodb://localhost:27017/user-authentication-refrral-web')
    .then(() => console.log('MongoDB Connected'))
    .catch((err) => console.log(err))


// ***************** USER ***************** //
app.use('/api', require('./routes/User'))

// Task
app.use('/api', require('./routes/Questions'));

// Point 
app.use('/api', require('./routes/Point'))

// Approve 
// Serve static files from the 'uploads' directory
app.use('/uploads', express.static('uploads'));
app.use('/api', require('./routes/User_Approve'))


app.listen(PORT, () => {
    console.log(`Server Started on PORT : ${PORT}`)
})