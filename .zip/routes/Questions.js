const express = require('express');
const router = express.Router()
const {addQuestion, getQuestion} = require('../controller/Questioning')

router.post('/addQuestion',addQuestion)
router.get('/getQuestion',getQuestion)

module.exports = router